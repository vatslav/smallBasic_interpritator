#include "operator.h"



extern struct context GLOBALS;//Из подсистемы variables. Глобальный контекст.
/* Инициализация интерпретатора */
void InitInterpreter()
{
	START_SUBSYSTEM_VARIABLES();//запуск подсистемы хранения переменных
}


int FILESIZE( FILE*file)
{
	long current_position = ftell( file );//Сохранили текущую поизицию в файле.

	fseek( file, 0, SEEK_END ); // Переезжаем в конец файла.
	long size = ftell(file );
	fseek( file, current_position, SEEK_SET );//Возвращаемся на старую позицию.

	return size;
}

int main( int argc, char* argv[] )
{
	FILE *file;
	if (argc<2){
		file = fopen("in.pas","rb");//Открываем в бинарном режиме, чтобы размер файла можно было легко и точно определить.
		if (file==0){
			serror("Can't open file in.pas");
			return 1;
		}
	}
	if (argc>2){
		printf("usage: %s [filename]", argv[0] );
		return 1;
	}
	if ( argc == 2 )
	{
		if ((file = fopen(argv[1],"rb"))==0){
			serror("Can't open file.");
			return 1;
		}
	}

	long file_size = FILESIZE( file );

	char* program = (char*)malloc( file_size + 1 );
	int count = fread( program, 1, file_size, file );

	fclose(file);

	program[count] = 0;

	printf("%s\n size = %d, strlen = %d\n", program, (int)file_size, strlen(program) );

	prog = program;

	InitInterpreter();

	return 0;
}
