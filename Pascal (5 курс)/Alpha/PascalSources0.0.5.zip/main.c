#include "variables.h"



extern struct context GLOBALS;//Из подсистемы variables. Глобальный контекст.
/* Инициализация интерпретатора */
void InitInterpreter()
{
	START_SUBSYSTEM_VARIABLES();//запуск подсистемы хранения переменных
}

int main( int argc, char* argv[] )
{
	InitInterpreter();

	
	addSimpleVariable( "hello", INTEGER );
	addSimpleVariable( "a", REAL );
//	debug();
	
	char type = getVariableType( "hello");	

	int* d = getIntegerVariable("hello");
	float* f = getRealVariable("a");
	
	
	//printf("%p %p\n", d, f );

	*f = 3.14;
	*d = 35;
	
	
	//getVariableType("hjl");
	//printf("%d %f\n", *getIntegerVariable("hello"), *getRealVariable("a") );
	
	debug();
	
	
	
	addSimpleVariable( "z", REAL );
	addSimpleVariable("m809", ARRAY );
	
	f = getRealVariable("z");
	*f = 2.72;
	f = getRealVariable("z");
	//printf("%p %f\n", f, *f );
	
	debug();
	return 0;
}
