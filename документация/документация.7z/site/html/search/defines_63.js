var searchData=
[
  ['const',['CONST',['../_globals_8h.html#a0c33b494a68ce28497e7ce8e5e95feff',1,'Globals.h']]],
  ['constant',['CONSTANT',['../_globals_8h.html#aa07f83a2de5a158b8643cdc36541b711',1,'Globals.h']]]
];
