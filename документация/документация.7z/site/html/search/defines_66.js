var searchData=
[
  ['false',['FALSE',['../_globals_8h.html#aa93f0eb578d23995850d61f7d61c55c1',1,'Globals.h']]],
  ['finished',['FINISHED',['../_globals_8h.html#a6a1e3fd193b6dd39939b3c436d1014ce',1,'Globals.h']]],
  ['for',['FOR',['../_globals_8h.html#a6634515171060cf2f7afd70a96cb9bde',1,'Globals.h']]]
];
