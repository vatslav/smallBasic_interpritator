var searchData=
[
  ['array',['ARRAY',['../_globals_8h.html#af579248b8d4c16c0aeba3dff9ee8b10a',1,'Globals.h']]],
  ['assignment',['ASSIGNMENT',['../_globals_8h.html#ad1cd2dc32d6952fc25d047025d3e2351',1,'Globals.h']]]
];
