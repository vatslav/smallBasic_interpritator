var searchData=
[
  ['then',['THEN',['../_globals_8h.html#ad9884c43f4f50a5852711a614f2343ac',1,'Globals.h']]],
  ['to',['TO',['../_globals_8h.html#af75a3636100d46e8e30e2797e2ec7471',1,'Globals.h']]],
  ['true',['TRUE',['../_globals_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'Globals.h']]]
];
