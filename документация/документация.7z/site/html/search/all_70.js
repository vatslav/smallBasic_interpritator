var searchData=
[
  ['prog',['prog',['../_globals_8h.html#acc6113e98e7cd24d9dcfa520749a5d3f',1,'Globals.h']]],
  ['programm',['PROGRAMM',['../_globals_8h.html#af0be866e1c88f14c14592125da5d1854',1,'Globals.h']]]
];
