var searchData=
[
  ['if',['IF',['../_globals_8h.html#ac138c68a0709c57bc5f7567abc1558eb',1,'Globals.h']]],
  ['integer',['INTEGER',['../_globals_8h.html#a91d43eadec33c80149f92e5abf5df58c',1,'Globals.h']]]
];
