var searchData=
[
  ['if',['IF',['../_globals_8h.html#ac138c68a0709c57bc5f7567abc1558eb',1,'Globals.h']]],
  ['integer',['INTEGER',['../_globals_8h.html#a91d43eadec33c80149f92e5abf5df58c',1,'Globals.h']]],
  ['is_5fgood_5fname',['is_good_name',['../_globals_8h.html#a62e7f181cb96768c9680872caed84aea',1,'Globals.h']]],
  ['isdelim',['isdelim',['../_globals_8h.html#aa445aae84aa989afc7a6b00ccf567951',1,'Globals.h']]],
  ['iswhite',['iswhite',['../_globals_8h.html#a1e4ca7bb7c46ebaa20afce215047fbc3',1,'Globals.h']]]
];
