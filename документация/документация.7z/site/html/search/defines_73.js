var searchData=
[
  ['system',['SYSTEM',['../_globals_8h.html#a21b97df85e65556468b28a576311271c',1,'Globals.h']]]
];
