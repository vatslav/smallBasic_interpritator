var searchData=
[
  ['typetoname',['typeToName',['../_globals_8h.html#ac0c636a09193e8786ea4452329252d78',1,'Globals.h']]]
];
