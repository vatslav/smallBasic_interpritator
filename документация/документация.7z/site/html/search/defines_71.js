var searchData=
[
  ['quote',['QUOTE',['../_globals_8h.html#a87978601e53a12294c82624e90c46b76',1,'Globals.h']]]
];
