var searchData=
[
  ['of',['OF',['../_globals_8h.html#a37666c9af451b99166c96df28aec5395',1,'Globals.h']]],
  ['operator',['OPERATOR',['../_globals_8h.html#adbebd8d1e72680a1abc369bf0ea849c0',1,'Globals.h']]],
  ['operators_5ftable',['OPERATORS_table',['../_globals_8h.html#a2087a943b36f3382beac90d70ffc31cb',1,'Globals.h']]]
];
