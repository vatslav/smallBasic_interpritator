var searchData=
[
  ['begin',['BEGIN',['../_globals_8h.html#ab766bbbee08d04b67e3fe599d6900873',1,'Globals.h']]]
];
