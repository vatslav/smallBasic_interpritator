var searchData=
[
  ['read',['READ',['../_globals_8h.html#ada74e7db007a68e763f20c17f2985356',1,'Globals.h']]],
  ['real',['REAL',['../_globals_8h.html#a4b654506f18b8bfd61ad2a29a7e38c25',1,'Globals.h']]]
];
