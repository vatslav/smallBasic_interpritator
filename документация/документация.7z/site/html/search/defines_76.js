var searchData=
[
  ['var',['VAR',['../_globals_8h.html#abca8dfa78652bc61165262af4fade766',1,'Globals.h']]],
  ['variable',['VARIABLE',['../_globals_8h.html#a86626d4d161f4c3958ce1cd99c5b974e',1,'Globals.h']]]
];
