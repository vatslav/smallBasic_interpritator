var searchData=
[
  ['while',['WHILE',['../_globals_8h.html#a4e6edb897a7a0bb16aa6d80aef24326a',1,'Globals.h']]],
  ['write',['WRITE',['../_globals_8h.html#aa10f470e996d0f51210d24f442d25e1e',1,'Globals.h']]],
  ['writeln',['WRITELN',['../_globals_8h.html#aab32f8a23894dda1fb3e74213921f7a4',1,'Globals.h']]]
];
