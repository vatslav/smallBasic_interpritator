var searchData=
[
  ['command',['command',['../structcommands.html#a8a9b33c07bbe0d690879af7acc1e0c67',1,'commands']]],
  ['content',['content',['../structvar.html#a73d02272f906583373bbe5a2513d3ba5',1,'var']]]
];
