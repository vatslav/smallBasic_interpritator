var structcommands =
[
    [ "command", "structcommands.html#a8a9b33c07bbe0d690879af7acc1e0c67", null ],
    [ "tok", "structcommands.html#a142499c28c9e2b02a0cc72bd9f325a00", null ]
];