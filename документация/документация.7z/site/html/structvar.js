var structvar =
[
    [ "content", "structvar.html#a73d02272f906583373bbe5a2513d3ba5", null ],
    [ "type", "structvar.html#a14c4c9123249048c30deb013acefa352", null ]
];