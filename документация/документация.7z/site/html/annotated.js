var annotated =
[
    [ "commands", "structcommands.html", "structcommands" ],
    [ "var", "structvar.html", "structvar" ]
];