var files =
[
    [ "Наш Pascal", "dir_9897a24ec43a626f2fa6918ccb967572.html", "dir_9897a24ec43a626f2fa6918ccb967572" ]
];